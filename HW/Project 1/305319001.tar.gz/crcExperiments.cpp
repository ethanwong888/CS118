#include <iostream>
#include <sstream>
#include <cstring>
#include <getopt.h>
#include <strings.h>
#include <string.h>

using namespace std;

string generator = "10001000010100001"; //x16 + x12 + x7 + x5 + 1
string message;
string output = "";
bool addShiftZeros;


char XOR(char a, char b){
    if (a != b) return '1';
    else return '0';
}

string makeCRC(string message, string gen){
    string msg = message;
    int genLen = generator.length();
    int genMinus = genLen - 1;

    // append 0s at the end of message
    if (addShiftZeros == 1){
        for(int x = 0; x < genMinus; x++){
            msg += '0';
        }    
    }

    // perform crc division (inspired by pseudocode in notes)
    while (msg.length() >= genLen){
        if (msg[0] == '0'){
            msg.erase(0, 1);
        }

        else if (msg[0] == '1'){
            msg.erase(0,1);
            for (int x = 0; x < genMinus; x++){
                if (msg[x] != gen[x+1])
                    msg[x] = '1';
                else
                    msg[x] = '0';
            }
        }

        else{
            cout << "This is not a binary string." << endl;
            return 0;
        }
    }
    return msg;
}



int main (int argc, char **argv) {
    int option;
    int state = 0;

    while ((option = getopt(argc, argv, "c:v:f:t:p:")) != -1) {
        switch(option) {
            case 'c':
                state = 0;
                message = optarg;
                addShiftZeros = 1;
                break;
            case 'v':
                state = 1;
                message = optarg;
                addShiftZeros = 0;
                break;
            case 'f':
                state = 2;
                message = optarg;
                addShiftZeros = 1;
                break;
            case 't':
                state = 3;
                message = optarg;
                addShiftZeros = 1;
                break;
            case 'p':
                state = 4;
                message = optarg;
                addShiftZeros = 1;
                break;

            default:
                return 1;
        }
    }

    // -c flag
    // generate the bitstring with its CRC attached
    if (state == 0){ 
        string crc = makeCRC(message, generator);
        cout << message + crc << endl;
        return 0;
    }

    // -v flag
    // check if input string has a valid CRC
    else if (state == 1){
        string crc = makeCRC(message, generator);
        int crcLen = crc.length() - 1;

        for (int x = 0; x <= crcLen; x++){
            if (crc[x] == '1'){
                // string is not consistent with CRC
                cout << "0" << endl;
                return 0;
            }
        }
        // string is consistent with CRC
        cout << "1" << endl;
        return 0;
    }

    // -f flag
    // undetected 4-bit errors
    else if (state == 2){
        generator = "11001000000000101"; //x16 + x15 + x12 + x2 + 1
        bool detected;
        string temp;
        string err;
        int errLen;
        string crc = makeCRC(message, generator);
        string msg = message + crc;
        int msgLen = msg.length();

        // nested for loops inspired by professor's pseudocode from lecture
        for (int a = 0; a < msgLen; a++){
            for (int b = a + 1; b < msgLen; b++){
                for (int c = b + 1; c < msgLen; c++){
                    for (int d = c + 1; d < msgLen; d++){
                        detected = 0;
                        temp = msg;

                        temp[a] = (msg[a] == '1') ? '0' : '1';

                        temp[b] = (msg[b] == '1') ? '0' : '1';

                        temp[c] = (msg[c] == '1') ? '0' : '1';

                        temp[d] = (msg[d] == '1') ? '0' : '1';

                        // check for undetected errors
                        err = makeCRC(temp, generator);
                        errLen = err.length();
                        for (int x = 0; x < errLen; x++){
                            if (err[x] == '1'){
                                // we don't care if error is detected
                                detected = 1;
                                break;
                            }
                        }
                        // print out undetected error
                        if (detected == 0){
                            cout << temp << endl;
                        }   
                    }
                }
            }
        }
        return 0;
    }
    
    // -t flag
    // undetected 5-bit errors (x16 + x15 + x12 + x2 + 1)
    else if (state == 3){
        generator = "11001000000000101"; //x16 + x15 + x12 + x2 + 1
        bool detected;
        string temp;
        string err;
        int errLen;
        int counter = 0;
        string crc = makeCRC(message, generator);
        string msg = message + crc;
        int msgLen = msg.length();

        // nested for loops inspired by professor's pseudocode from lecture
        for (int a = 0; a < msgLen; a++){
            for (int b = a + 1; b < msgLen; b++){
                for (int c = b + 1; c < msgLen; c++){
                    for (int d = c + 1; d < msgLen; d++){
                        for (int e = d + 1; e < msgLen; e++){
                            detected = 0;
                            temp = msg;

                            temp[a] = (msg[a] == '1') ? '0' : '1';

                            temp[b] = (msg[b] == '1') ? '0' : '1';

                            temp[c] = (msg[c] == '1') ? '0' : '1';

                            temp[d] = (msg[d] == '1') ? '0' : '1';

                            temp[e] = (msg[e] == '1') ? '0' : '1';

                            // check for undetected errors
                            err = makeCRC(temp, generator);
                            errLen = err.length();
                            for (int x = 0; x < errLen; x++){
                                if (err[x] == '1'){
                                    // we don't care if error is detected
                                    detected = 1;
                                    break;
                                }
                            }
                            // print out undetected error
                            if (detected == 0){
                                counter += 1;
                            }
                        }  
                    }
                }
            }
        }
        cout << counter << endl;
        return 0;
    }

    // -p flag
    // undetected 5-bit errors (x16 + x15 + x2 +1)
    else if (state == 4){
        generator = "11000000000000101"; //x16 + x15 + x2 + 1
        bool detected;
        string temp;
        string err;
        int errLen;
        int counter = 0;
        string crc = makeCRC(message, generator);
        string msg = message + crc;
        int msgLen = msg.length();

        // nested for loops inspired by professor's pseudocode from lecture
        for (int a = 0; a < msgLen; a++){
            for (int b = a + 1; b < msgLen; b++){
                for (int c = b + 1; c < msgLen; c++){
                    for (int d = c + 1; d < msgLen; d++){
                        for (int e = d + 1; e < msgLen; e++){
                            detected = 0;
                            temp = msg;

                            temp[a] = (msg[a] == '1') ? '0' : '1';

                            temp[b] = (msg[b] == '1') ? '0' : '1';

                            temp[c] = (msg[c] == '1') ? '0' : '1';

                            temp[d] = (msg[d] == '1') ? '0' : '1';

                            temp[e] = (msg[e] == '1') ? '0' : '1';

                            // check for undetected errors
                            err = makeCRC(temp, generator);
                            errLen = err.length();
                            for (int x = 0; x < errLen; x++){
                                if (err[x] == '1'){
                                    // we don't care if error is detected
                                    detected = 1;
                                    break;
                                }
                            }
                            // print out undetected error
                            if (detected == 0){
                                counter += 1;
                            }
                        }  
                    }
                }
            }
        }
        cout << counter << endl;
        return 0;
    }
}